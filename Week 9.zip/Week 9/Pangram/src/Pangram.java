import java.util.Scanner; 

public class Pangram {
	
	public static void main(String[] args) {
		String Sentn = "Sixty zippers were quickly picked from the woven jute bag";
	    boolean[] CountList = new boolean[57];
	    int index = 0;
	    int indicate = 1;
	    for (int i = 0; i < Sentn.length(); i++) {
	       
	    	if ( Sentn.charAt(i) >= 'A' && Sentn.charAt(i) <= 'Z') {
	           index = Sentn.charAt(i) - 'A';
	         }else if( Sentn.charAt(i) >= 'a' && Sentn.charAt(i) <= 'z') {
	            index = Sentn.charAt(i) - 'a';
	      }
	      CountList[index] = true;
	   }
	   
	    for (int i = 0; i <= 25; i++) {
	      if (CountList[i] == false)
	      indicate = 0;
	   }
	      
	   if (indicate == 1) {  
	       System.out.println("The above string is a pangram.");}
	   else{
		   System.out.println("The above string is not a pangram.");
	   }
	}
}
