import java.util.Scanner; 
public class Words {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);  
		
		System.out.println("Enter your sentence: "); 
		String stored = input.nextLine();  
		
		String sentn[] = stored.split(" ");
		
		String ans = "";
		
		for (int x = sentn.length -1; x >= 0; x--) { 
			ans += sentn[x] + " ";
		}
		
		System.out.println("Reversed: " + ans);
		
		}
	}


